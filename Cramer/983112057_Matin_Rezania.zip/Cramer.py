# coding: utf-8
def Cramer(m, c):
    '''solves equations for values of x  using the cramer`s rule and returns x

    Keyword arguments:
    m -- coefficient matrix
    c -- constants
    '''

    # Calculate The Main Matrix's order
    n = len(m)
    main_det = det(m)
    print(f"Main Matrix's determinant: {main_det}")

    # Build New Matrix with Substitutions
    if main_det != 0:
        x = []
        for t in range(n):
            matrix_sub = []
            for i in range(n):
                matrix_sub.append([])
                for j in range(n):
                    if j == t:
                        matrix_sub[i].append(c[i])
                    else:
                        matrix_sub[i].append(m[i][j])

            # Calc Determinant with Substitution
            sub_det = det(matrix_sub)
            print(f"Sub_matrix {t+1}'s determinant: {sub_det}")

            x.append(sub_det / main_det)

        print('\nSolution set:')
        for t in range(n):
            print(f'x{t + 1} = {x[t]}')
        return x

    else:
        print("Couldn't finish algorithm Because The determinant of the Matrix m is 0.")
        return 0
